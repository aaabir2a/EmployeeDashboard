

import './App.css'
import EmployeeDashboard from './pages/EmployeeDashboard'

function App() {


  return (
    <>
      <EmployeeDashboard />
    </>
  )
}

export default App
